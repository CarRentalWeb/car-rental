export const environment = {
  production: true,
    apiUrl: 'http://rentback-env.mqjdm7ytac.us-east-2.elasticbeanstalk.com/api'
};
